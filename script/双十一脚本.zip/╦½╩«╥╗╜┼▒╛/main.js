// function start(){
//   // 加载本地配置
var config = storages.create("dobule_eleven_config");

// 缓存变量
var picRepeatTimes = config.get('picRepeatTimes')
var defaultTime = config.get('defaultTime')

var Automator = require("./src/Automator.js");
var Unlock = require("./src/Unlock.js");
var Pictrue = require("./src/Pictrue.js");

var entry = new Pictrue({"targetPic":'./img/t_entry.jpg','threshold':0.9})
entry.findPic()

// toast('开始')

// }
 
// module.exports = start;