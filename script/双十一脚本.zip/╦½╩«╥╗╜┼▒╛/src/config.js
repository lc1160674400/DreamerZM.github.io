"ui";
/**
 * 默认配置
 */
var config = storages.create("dobule_eleven_config");
// 默认执行配置
var default_conf = {
  picRepeatTimes:20,
  defaultTime:2000
};
var isError = false
if (!config.contains("picRepeatTimes")) {
  // 储存默认配置到本地
  Object.keys(default_conf).forEach(function(key) {
    config.put(key, default_conf[key]);
  });
}
ui.layout(
    <vertical padding="16">
         <text text="设置图片重复查找次数" textColor="black" textSize="16sp" marginTop="16"/>
         <input id="picTimes" inputType="number" hint="默认失败后重复查找数：5" text="{{config.get('picRepeatTimes')}}"/>
         <text text="设置每一次点击之后时间间隔" textColor="black" textSize="16sp" marginTop="16"/>
         <input id="defaultTime" inputType="number" hint="时间过短可能导致查找图片失败" text="{{config.get('defaultTime')}}"/>
         <button w="*" id="clear" text="清除本地储存" gravity="center" layout_gravity="center" />
         {/* <button id="default" text="使用默认配置（推荐）" w="auto" style="Widget.AppCompat.Button.Colored"/> */}
         <button id="change" text="修改" w="*" style="Widget.AppCompat.Button.Colored"/>
    </vertical>
);


ui.change.click(()=>{
  var pic_times = ui.picTimes.text()
  var default_time = ui.defaultTime.text()
  const PIC_TIME_RANGE = [1,10]
  const DEFAULT_TIME_RANGE = [1000,10000]
  
  var config = storages.create("dobule_eleven_config");
  if(pic_times < PIC_TIME_RANGE[0] || pic_times > PIC_TIME_RANGE[1]){
    ui.picTimes.setError("图片查找次数输入有误");
    isError = true
    return
  }
  if(default_time < DEFAULT_TIME_RANGE[0] || default_time > DEFAULT_TIME_RANGE[1]){
    ui.defaultTime.setError("时间间隔输入有误");
    isError = true
    return
  }
  config.put('picRepeatTimes', pic_times);
  config.put('defaultTime', default_time);
  // var START = require('./init.js')
  
  engines.execScriptFile("./main.js");
  // START.begin = true
})

// 清除本地储存 
ui.clear.on("click", () => {
  confirm("确定要清除本地储存吗？")
    .then(ok => {
      if (ok) {
        storages.remove("dobule_eleven_config");
        toast("清除成功");
      }
    });
});